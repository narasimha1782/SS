'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function PlanPage() {
  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="relative pt-20 pb-16 bg-gradient-to-br from-blue-50 to-orange-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-gray-900 mb-4">
              Choose Your Solar Plan
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Whether you're a customer or promoter, we have the perfect plan for you
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Customer Plan - Highlighted */}
            <div className="relative bg-white rounded-2xl shadow-2xl p-8 border-4 border-orange-500">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="bg-orange-500 text-white px-6 py-2 rounded-full text-sm font-semibold">
                  MOST POPULAR
                </span>
              </div>
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-user-line text-white text-2xl"></i>
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Customer Plan</h2>
                <p className="text-gray-600 mt-2">Perfect for homeowners wanting solar power</p>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700">Zero initial payment</span>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700">Complete documentation support</span>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700">Bank loan processing</span>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700">Professional installation</span>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700">Subsidy processing</span>
                </div>
              </div>

              <Link href="/signup" className="w-full bg-orange-500 text-white py-4 rounded-full text-lg font-semibold hover:bg-orange-600 transition-colors cursor-pointer text-center block whitespace-nowrap">
                Get Started as Customer
              </Link>
            </div>

            {/* Promoter Plan */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-team-line text-white text-2xl"></i>
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Promoter Plan</h2>
                <p className="text-gray-600 mt-2">Earn by referring customers and promoters</p>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700">₹1000 per direct customer</span>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700">₹700 from Level 1 promoters</span>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700">₹500 from Level 2 promoters</span>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700">Unlimited earning potential</span>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700">Marketing support provided</span>
                </div>
              </div>

              <Link href="/signup" className="w-full bg-blue-500 text-white py-4 rounded-full text-lg font-semibold hover:bg-blue-600 transition-colors cursor-pointer text-center block whitespace-nowrap">
                Become a Promoter
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Customer Benefits Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Make Your Solar Loan Free!
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Revolutionary referral system that can eliminate your EMI payments completely
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            {/* EMI ≤ 2200 Plan */}
            <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-8 mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                For EMI ≤ ₹2,200 (Most Common)
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-white rounded-lg p-6 text-center shadow-lg">
                  <div className="text-4xl font-bold text-green-600 mb-2">3</div>
                  <div className="text-gray-600 mb-2">Direct Referrals</div>
                  <div className="text-2xl font-bold text-orange-500">= 1 EMI</div>
                </div>
                <div className="bg-white rounded-lg p-6 text-center shadow-lg">
                  <div className="text-4xl font-bold text-blue-600 mb-2">9</div>
                  <div className="text-gray-600 mb-2">Level 2 Customers</div>
                  <div className="text-2xl font-bold text-orange-500">= 5 EMIs</div>
                </div>
                <div className="bg-white rounded-lg p-6 text-center shadow-lg">
                  <div className="text-4xl font-bold text-purple-600 mb-2">27</div>
                  <div className="text-gray-600 mb-2">Level 3 Customers</div>
                  <div className="text-2xl font-bold text-orange-500">= 14 EMIs</div>
                </div>
              </div>

              <div className="text-center">
                <div className="inline-block bg-white rounded-lg p-6 shadow-lg">
                  <h4 className="text-xl font-bold text-gray-900 mb-2">Complete One Set (3-9-27)</h4>
                  <div className="text-3xl font-bold text-green-600">Total: 20 EMIs Paid!</div>
                </div>
              </div>
            </div>

            {/* Free Solar Achievement */}
            <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl p-8 text-white text-center">
              <h3 className="text-3xl font-bold mb-4">🎉 Complete 3 Sets = FREE SOLAR! 🎉</h3>
              <p className="text-xl mb-4">3 Sets × 20 EMIs = 60 EMIs Paid</p>
              <p className="text-lg">Your loan is completely paid off and you enjoy free solar power for life!</p>
            </div>
          </div>
        </div>
      </section>

      {/* Higher EMI Plans */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Higher EMI Plans
            </h2>
            <p className="text-xl text-gray-600">
              For EMI above ₹2,200, referral requirements increase proportionally
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="bg-white rounded-lg p-6 text-center shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-4">₹2,201 - ₹2,750</h3>
              <div className="text-3xl font-bold text-orange-500 mb-2">4</div>
              <p className="text-gray-600">Direct Referrals Required</p>
            </div>
            <div className="bg-white rounded-lg p-6 text-center shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-4">₹2,751 - ₹3,300</h3>
              <div className="text-3xl font-bold text-orange-500 mb-2">5</div>
              <p className="text-gray-600">Direct Referrals Required</p>
            </div>
            <div className="bg-white rounded-lg p-6 text-center shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Above ₹3,300</h3>
              <div className="text-3xl font-bold text-orange-500 mb-2">6+</div>
              <p className="text-gray-600">Direct Referrals Required</p>
            </div>
          </div>
        </div>
      </section>

      {/* Promoter Benefits */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Promoter Earning Structure
            </h2>
            <p className="text-xl text-gray-600">
              Build your network and earn from multiple levels
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-8 text-center">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-user-line text-white text-2xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Direct Customers</h3>
                <div className="text-4xl font-bold text-green-600 mb-2">₹1,000</div>
                <p className="text-gray-600">Per customer you directly refer</p>
              </div>

              <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-8 text-center">
                <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-team-line text-white text-2xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Level 1 Promoters</h3>
                <div className="text-4xl font-bold text-blue-600 mb-2">₹700</div>
                <p className="text-gray-600">From promoters you directly recruit</p>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-8 text-center">
                <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-group-line text-white text-2xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Level 2 Promoters</h3>
                <div className="text-4xl font-bold text-purple-600 mb-2">₹500</div>
                <p className="text-gray-600">From sub-promoters in your network</p>
              </div>
            </div>

            <div className="mt-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg p-8 text-white text-center">
              <h3 className="text-2xl font-bold mb-4">Example Promoter Earning</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-lg">
                <div>10 Direct Customers = ₹10,000</div>
                <div>5 Level 1 Promoters = ₹3,500</div>
                <div>10 Level 2 Promoters = ₹5,000</div>
              </div>
              <div className="text-3xl font-bold mt-4">Total Monthly: ₹18,500+</div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              How The System Works
            </h2>
            <p className="text-xl text-gray-600">
              Simple and transparent process for everyone
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  1
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Customer Registration</h3>
                  <p className="text-gray-600">Customer registers through promoter or directly. We collect all necessary documents.</p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  2
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Portal Registration & Site Visit</h3>
                  <p className="text-gray-600">We register customer in PM Surya Ghar portal and conduct technical site analysis.</p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  3
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Bank Loan Processing</h3>
                  <p className="text-gray-600">We facilitate loan approval with our partner nationalized banks.</p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  4
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Installation & Commissioning</h3>
                  <p className="text-gray-600">Professional installation by certified technicians with quality assurance.</p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  5
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Subsidy Processing</h3>
                  <p className="text-gray-600">We handle all government subsidy paperwork and ensure you receive maximum benefits.</p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  6
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Referral Rewards</h3>
                  <p className="text-gray-600">As customers refer others and installations complete, EMI payments are made automatically.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-orange-500 to-red-500">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Ready to Start Your Solar Journey?
          </h2>
          <p className="text-xl text-white mb-8 max-w-2xl mx-auto">
            Choose your path - become a customer and enjoy free solar power, or become a promoter and build your income
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/signup" className="bg-white text-orange-500 px-8 py-4 rounded-full text-lg font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap">
              Join as Customer
            </Link>
            <Link href="/signup" className="border-2 border-white text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-white hover:text-orange-500 transition-colors cursor-pointer whitespace-nowrap">
              Become Promoter
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}