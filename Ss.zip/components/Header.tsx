'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
            <i className="ri-sun-line text-white text-xl"></i>
          </div>
          <span className="text-xl font-bold text-gray-800" style={{ fontFamily: 'Pacifico, serif' }}>
            SolarPro
          </span>
        </div>

        <nav className="hidden md:flex items-center space-x-8">
          <Link href="/" className="text-gray-700 hover:text-orange-500 transition-colors cursor-pointer whitespace-nowrap">
            Home
          </Link>
          <Link href="/plan" className="text-gray-700 hover:text-orange-500 transition-colors cursor-pointer whitespace-nowrap">
            Plan
          </Link>
          <Link href="/contact" className="text-gray-700 hover:text-orange-500 transition-colors cursor-pointer whitespace-nowrap">
            Contact
          </Link>
          <Link href="/signin" className="bg-orange-500 text-white px-4 py-2 rounded-full hover:bg-orange-600 transition-colors cursor-pointer whitespace-nowrap">
            Sign In
          </Link>
          <Link href="/signup" className="border border-orange-500 text-orange-500 px-4 py-2 rounded-full hover:bg-orange-500 hover:text-white transition-colors cursor-pointer whitespace-nowrap">
            Sign Up
          </Link>
        </nav>

        <button 
          className="md:hidden w-6 h-6 flex items-center justify-center cursor-pointer"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <i className={`ri-${isMobileMenuOpen ? 'close' : 'menu'}-line text-xl text-gray-700`}></i>
        </button>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden bg-white/95 backdrop-blur-md border-t">
          <nav className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <Link href="/" className="text-gray-700 hover:text-orange-500 transition-colors cursor-pointer">
              Home
            </Link>
            <Link href="/plan" className="text-gray-700 hover:text-orange-500 transition-colors cursor-pointer">
              Plan
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-orange-500 transition-colors cursor-pointer">
              Contact
            </Link>
            <Link href="/signin" className="bg-orange-500 text-white px-4 py-2 rounded-full hover:bg-orange-600 transition-colors cursor-pointer text-center whitespace-nowrap">
              Sign In
            </Link>
            <Link href="/signup" className="border border-orange-500 text-orange-500 px-4 py-2 rounded-full hover:bg-orange-500 hover:text-white transition-colors cursor-pointer text-center whitespace-nowrap">
              Sign Up
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}